/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports", "N/log", "N/ui/serverWidget", "../module/jtc_import_ids"], function (require, exports, log, UI, jtc_import_ids_1) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    var onRequest = function (ctx) {
        try {
            var form = UI.createForm({ title: jtc_import_ids_1.constates.FORM.TITLE });
            if (ctx.request.method == "GET") {
                getForm(ctx, form);
            }
            else {
                postForm(ctx, form);
            }
        }
        catch (error) {
            log.error('jtc_load_file_csv_st_mst.onRequst', error);
        }
    };
    exports.onRequest = onRequest;
    var getForm = function (ctx, form) {
        try {
            var file = form.addField({
                id: jtc_import_ids_1.constates.FORM.FIELDS.CSV_FIELD.ID,
                label: jtc_import_ids_1.constates.FORM.FIELDS.CSV_FIELD.LABEL,
                type: UI.FieldType.FILE
            });
            form.addSubmitButton({ label: "Importar CSV" });
            ctx.response.writePage(form);
        }
        catch (error) {
        }
    };
    var postForm = function (ctx, form) {
        try {
            var body = ctx.request.parameters;
            var file = body.custpage_csv_file;
            log.debug("file", file);
            ctx.response.write("ok");
        }
        catch (error) {
        }
    };
});
