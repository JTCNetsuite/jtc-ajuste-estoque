/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.constates = void 0;
    exports.constates = {
        FORM: {
            TITLE: 'Importação de Ajuste de Estoque',
            FIELDS: {
                CSV_FIELD: {
                    ID: 'custpage_csv_file',
                    LABEL: 'Arquivo'
                }
            }
        }
    };
});
