/**
 * @NAPIVersion 2.x
 * @NScriptType MapReduceScript
 */ 
