/**
 * @NAPIVersion 2.x
 * @NScriptType Suitelet
 */
define(["require", "exports", "N/log", "../models/jtc_load_file_csv_st_MSR"], function (require, exports, log, MSR) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    var onRequest = function (ctx) {
        try {
            MSR.onRequest(ctx);
        }
        catch (error) {
            log.error("jtc_load_file_csv_ST.onRequest", error);
        }
    };
    exports.onRequest = onRequest;
});
