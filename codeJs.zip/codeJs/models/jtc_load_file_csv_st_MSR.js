/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports", "N/log", "N/record", "N/ui/serverWidget", "../module/jtc_import_ids", "N/file", "N/redirect", "N/task"], function (require, exports, log, record, UI, jtc_import_ids_1, file, redirect, task) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.onRequest = void 0;
    var onRequest = function (ctx) {
        try {
            var form = UI.createForm({ title: jtc_import_ids_1.constates.FORM.TITLE });
            if (ctx.request.method == "GET") {
                getForm(ctx, form);
            }
            else {
                postForm(ctx, form);
            }
        }
        catch (error) {
            log.error('jtc_load_file_csv_st_mst.onRequst', error);
        }
    };
    exports.onRequest = onRequest;
    var getForm = function (ctx, form) {
        try {
            var file_1 = form.addField({
                id: jtc_import_ids_1.constates.FORM.FIELDS.CSV_FIELD.ID,
                label: jtc_import_ids_1.constates.FORM.FIELDS.CSV_FIELD.LABEL,
                type: UI.FieldType.FILE
            });
            var subsidary = form.addField({
                id: jtc_import_ids_1.constates.FORM.FIELDS.SUBSIDIARY.ID,
                label: jtc_import_ids_1.constates.FORM.FIELDS.SUBSIDIARY.LABEL,
                type: UI.FieldType.SELECT,
                source: String(record.Type.SUBSIDIARY)
            });
            var conta = form.addField({
                id: jtc_import_ids_1.constates.FORM.FIELDS.ACCOUNT.ID,
                label: jtc_import_ids_1.constates.FORM.FIELDS.ACCOUNT.LABEL,
                type: UI.FieldType.SELECT,
                source: String(record.Type.ACCOUNT)
            });
            var localidade = form.addField({
                id: jtc_import_ids_1.constates.FORM.FIELDS.LOCALIDADE.ID,
                label: jtc_import_ids_1.constates.FORM.FIELDS.LOCALIDADE.LABEL,
                type: UI.FieldType.SELECT,
                source: String(record.Type.LOCATION)
            });
            form.addSubmitButton({ label: "Importar CSV" });
            ctx.response.writePage(form);
        }
        catch (error) {
        }
    };
    var postForm = function (ctx, form) {
        try {
            var file_form = ctx.request.files.custpage_csv_file;
            var body = ctx.request.parameters;
            var subsidary = body.custpage_sub;
            var localidade = body.custpage_localidade;
            var account = body.custpage_account;
            file_form.folder = 3278;
            var idFile = file_form.save();
            log.debug("fileID", idFile);
            var fileCsv = file.load({ id: idFile });
            var content = fileCsv.getContents();
            var recAdInventory = record.create({
                type: record.Type.INVENTORY_ADJUSTMENT,
                isDynamic: true
            });
            recAdInventory.setValue({ fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBSIDIARY, value: subsidary });
            recAdInventory.setValue({ fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.LOCALIDADE, value: localidade });
            recAdInventory.setValue({ fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.CONTA, value: account });
            recAdInventory.selectNewLine({ sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID });
            recAdInventory.setCurrentSublistValue({
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID,
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ITEM,
                value: 442
            });
            recAdInventory.setCurrentSublistValue({
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID,
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.QTDE_ADJ,
                value: 1
            });
            recAdInventory.setCurrentSublistValue({
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID,
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.LOCALIDADE,
                value: localidade
            });
            recAdInventory.setCurrentSublistValue({
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID,
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.PRECO_UNIT,
                value: 1.02
            });
            var inventorydetail = recAdInventory.getCurrentSublistSubrecord({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.ID,
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID
            });
            var inv = inventorydetail.selectNewLine({
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID
            });
            inventorydetail.setCurrentSublistValue({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.NUM_SERIAL,
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID,
                value: 'teste'
            });
            inventorydetail.setCurrentSublistValue({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.QUATITY,
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID,
                value: 1
            });
            inventorydetail.commitLine({ sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID });
            recAdInventory.commitLine({ sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID });
            var sublistId = jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID;
            var idInvRec = recAdInventory.save({ ignoreMandatoryFields: true });
            // if (values.length > 0) {
            log.audit('idInvRec', idInvRec);
            var mapReduceTask = task.create({
                taskType: task.TaskType.MAP_REDUCE,
                scriptId: jtc_import_ids_1.constates.SCRIPT_MAP_REDUCE.ID,
                params: {
                    custscript_jtc_ajuste_estoque_id: idInvRec,
                    custscript_jtc_id_file_csv: idFile
                }
            });
            var idTask = mapReduceTask.submit();
            redirect.toRecord({
                type: record.Type.INVENTORY_ADJUSTMENT,
                id: idInvRec
            });
            // }
            ctx.response.write(content);
        }
        catch (error) {
            log.error("jtc_load_file_csv_st_MSR.postForm", error);
        }
    };
});
