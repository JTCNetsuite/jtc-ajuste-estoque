/**
 * @NAPIVersion 2.x
 * @NModuleScope public
 */
define(["require", "exports", "N/runtime", "N/log", "../module/jtc_import_ids", "N/file", "N/search", "N/record"], function (require, exports, runtime, log, jtc_import_ids_1, file, search, record) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    var getInputData = function () {
        try {
            var currScipt = runtime.getCurrentScript();
            var idFile = currScipt.getParameter({ name: jtc_import_ids_1.constates.SCRIPT_MAP_REDUCE.ID_FILE_CSV });
            log.debug("id file", idFile);
            var fileCsv = file.load({ id: idFile });
            var content = fileCsv.getContents();
            var response = formatCSVToNetsuite(content);
            log.debug("reposnse", response);
            return response;
        }
        catch (e) {
            log.error("jtc_make_ajuste_estoque_mr_MSR.getInputData", e);
        }
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        try {
            var currScipt = runtime.getCurrentScript();
            var idInv = currScipt.getParameter({ name: jtc_import_ids_1.constates.SCRIPT_MAP_REDUCE.ID_REC_AJUSTE });
            var recAdInventory = record.load({
                type: record.Type.INVENTORY_ADJUSTMENT,
                id: idInv,
                isDynamic: true
            });
            var sublistId = jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ID;
            var value = String(ctx.value).split(";");
            log.debug("ctx", value);
            var firstline = recAdInventory.getSublistValue({
                sublistId: sublistId,
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ITEM,
                line: 0
            });
            if (firstline == 442) {
                recAdInventory.removeLine({ sublistId: sublistId, line: 0 });
            }
            recAdInventory.selectNewLine({ sublistId: sublistId });
            recAdInventory.setCurrentSublistValue({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.ITEM,
                sublistId: sublistId,
                value: Number(value[0])
            });
            recAdInventory.setCurrentSublistValue({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.QTDE_ADJ,
                sublistId: sublistId,
                value: Number(value[1])
            });
            recAdInventory.setCurrentSublistValue({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.LOCALIDADE,
                sublistId: sublistId,
                value: String(value[4])
            });
            var valor_string = String(value[5]).split('"')[1];
            var valor = Number(valor_string.replace(",", "."));
            recAdInventory.setCurrentSublistValue({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBLIST_INVENTORY.PRECO_UNIT,
                sublistId: sublistId,
                value: valor
            });
            var inventorydetail = recAdInventory.getCurrentSublistSubrecord({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.ID,
                sublistId: sublistId
            });
            var inv = inventorydetail.selectNewLine({
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID
            });
            log.debug('inv', inv);
            if (Number(value[1]) >= 0) {
                inventorydetail.setCurrentSublistValue({
                    fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.NUM_SERIAL,
                    sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID,
                    value: value[3]
                });
            }
            else {
                log.debug("lote", value[3]);
                var createSearchInventory = search.create({
                    type: 'inventorynumber',
                    filters: [
                        ['inventorynumber', search.Operator.CONTAINS, String(value[3]).replace(" ", "")],
                        "AND",
                        ["item.internalid", search.Operator.ANYOF, value[0]],
                        "AND",
                        ["location", search.Operator.ANYOF, value[4]]
                    ],
                    columns: [
                        search.createColumn({ name: 'inventorynumber' })
                    ]
                }).run().getRange({ start: 0, end: 1 });
                log.debug("createSearchInventory", createSearchInventory);
                inventorydetail.setCurrentSublistValue({
                    fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.NEGATIVE_SET_SERIAL,
                    sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID,
                    value: createSearchInventory[0].id
                });
            }
            inventorydetail.setCurrentSublistValue({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.QUATITY,
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID,
                value: value[1]
            });
            var date = String(value[2]).split("/");
            inventorydetail.setCurrentSublistValue({
                fieldId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.DATA_VALIDADE,
                sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID,
                value: new Date(value[2])
            });
            var line = inventorydetail.commitLine({ sublistId: jtc_import_ids_1.constates.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID });
            var lin_inv = recAdInventory.commitLine({ sublistId: sublistId });
            var idIventory = recAdInventory.save();
            log.audit('idInventory', idIventory);
        }
        catch (e) {
            log.error("jtc_make_ajuste_estoque_mr_MSR.map", e);
        }
    };
    exports.map = map;
    var formatCSVToNetsuite = function (content) {
        var ret = [];
        var x = content.split("\n");
        log.debug("x", x);
        x.shift();
        x.pop();
        for (var i = 0; i < x.length; i++) {
            // log.debug(i, x[i])
            ret.push(x[i]);
        }
        return ret;
    };
});
// for (var i=0; i < values.length; i++) {
//     const value = values[i].split(";")
//     recAdInventory.selectNewLine({sublistId: sublistId})
//     recAdInventory.setCurrentSublistValue({
//         fieldId: CTS.ADJ_INVENTORY.SUBLIST_INVENTORY.ITEM,
//         sublistId: sublistId,
//         value: Number(value[0])
//     })
//     recAdInventory.setCurrentSublistValue({
//         fieldId: CTS.ADJ_INVENTORY.SUBLIST_INVENTORY.QTDE_ADJ,
//         sublistId: sublistId,
//         value: value[1]
//     })
//     recAdInventory.setCurrentSublistValue({
//         fieldId: CTS.ADJ_INVENTORY.SUBLIST_INVENTORY.LOCALIDADE,
//         sublistId: sublistId,
//         value: String(value[4]).split(" ")[0]
//     })
//     const inventorydetail = recAdInventory.getCurrentSublistSubrecord({
//         fieldId: CTS.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.ID,
//         sublistId: sublistId
//     })
//     const inv = inventorydetail.selectNewLine({
//         sublistId: CTS.ADJ_INVENTORY.SUBRECORD_INVENTORY_DETAIL.SUBLIST_INV_DETAIL.ID
//     })
//     log.debug('inv', inv)
//     log.debug('line', line)
//     log.audit("idInv", idInv)
// }
