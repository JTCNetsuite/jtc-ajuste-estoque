/**
 * @NAPIVersion 2.x
/**
 * @NApiVersion 2.x
 * @NScriptType MapReduceScript
 */
define(["require", "exports", "../models/jtc_make_ajuste_estoque_mr_MSR", "N/log"], function (require, exports, MSR, log) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    exports.map = exports.getInputData = void 0;
    var getInputData = function () {
        try {
            return MSR.getInputData();
        }
        catch (e) {
            log.error("jtc_make_ajuste_estoque_MR.getInputData", e);
        }
    };
    exports.getInputData = getInputData;
    var map = function (ctx) {
        try {
            MSR.map(ctx);
        }
        catch (e) {
            log.error("jtc_make_ajuste_estoque_MR.map", e);
        }
    };
    exports.map = map;
});
